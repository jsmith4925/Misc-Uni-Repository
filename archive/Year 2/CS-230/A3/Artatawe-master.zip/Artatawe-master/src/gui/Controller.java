package sample;
import javafx.scene.layout.VBox;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;


public class Controller {
    public void showMessage(){
        System.out.print("How are you?");
    }
    public void set(){

    }
}
