Extra Java Practice
(Liam O'Reilly)
===================

In this folder you find a set of Lab Classes for the module
CSF101. This is a different module to CS-110 (that you studied last
term), however it covered the same topics.

If you want to get more practice at "basic" Java (i.e., Java without
using classes) then feel free to attempt the tasks contained in these
lab classes.

****************************************************************
***** These Lab Classes are not worth any marks for CS-115 *****
****************************************************************

They are simply provided in case you want some extra practice.

Please note I have simply collected together these lab classes from
CSF101. All the resources to complete these tasks can be found in the
"Resources" folder included here. Ignore the instructions for Lab
Classes 7 and 9 that tell you to download the resources from
Blackboard.

Happy Coding :-)
