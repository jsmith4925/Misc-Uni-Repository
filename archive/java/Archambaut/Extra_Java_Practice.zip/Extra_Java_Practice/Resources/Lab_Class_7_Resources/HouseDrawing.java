import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JComponent;

/**
 * This program is the starting point for Task 16 (drawing a house) in the LabBook.
 *
 */
public class HouseDrawing {

	/**
	 *  This main method sets up the window and drawing canvas.
	 *  Do not edit this method, other than to change the frame dimensions. 
	 *  @param args Not used.
	 */
	public static void main(String[] args) {
		final int FRAME_WIDTH = 375;
		final int FRAME_HEIGHT = 625;
		
		// Create new window
		JFrame frame = new JFrame();
		frame.setSize(FRAME_WIDTH, FRAME_HEIGHT);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Add a graphic canvas to draw on
		JComponent component = new JComponent() {
			public void paintComponent(Graphics g) {
				draw(g);
			}
		};
		frame.add(component);
		frame.setVisible(true);
	}
	
	/**
	 * This method is called when drawing is required and draws the entire contents of the window.
	 * You need to modify the contents of this method to draw what is required. 
	 * @param g The graphics context to draw to.
	 */
	public static void draw(Graphics g) {
		final int WINDOW_SIZE = 100;
		final int WINDOW_BAR_WIDTH = 5;
		
		// Draw house outline
		drawPlainHouse(g, 25, 200, 300, 350, 100);
		// Draw bottom left window
		drawWindow(g, 50, 400, WINDOW_SIZE, WINDOW_SIZE, WINDOW_BAR_WIDTH);
	}
	
	/**
	 * Draws a plain house. 
	 * @param g The graphics context to draw to.
	 * @param x The x coordinate of the house (rectangular part), i.e., the x value of the top left corner disregarding roof.
	 * @param y The y coordinate of the house (rectangular part), i.e., the y value of the top left corner disregarding roof. 
	 * @param width The width of the house.
	 * @param height The height of the house (without roof).
	 * @param roofHeight The height of the root.
	 * 
	 */
	public static void drawPlainHouse(Graphics g, int x, int y, int width, int height, int roofHeight) { 
		//Draw main building outline
		g.setColor(Color.PINK);
		g.fillRect(x, y, width, height);
		// Draw round roof		
		g.fillOval(x, y - roofHeight, width, roofHeight * 2);
	}
		
	/**
	 * Draws a window with dividers separating the glass into four sections.
	 * @param g The graphics context to draw to.
	 * @param x The x coordinate of the window, i.e., the x value of the top left corner.
	 * @param y The y coordinate of the window, i.e., the y value of the top left corner. 
	 * @param width The width of the window.
	 * @param height The height of the window.
	 * @param dividerWidth The width of the dividers of the window.	 
	 */
	public static void drawWindow(Graphics g, int x, int y, int width, int height, int dividerWidth) {
		// Draw background
		g.setColor(Color.BLUE);
		g.fillRect(x, y, width, height);
		
		// Draw dividers
		g.setColor(Color.WHITE);
		g.fillRect(x, y + (height / 2) - (dividerWidth / 2), width, dividerWidth);
		g.fillRect(x + (width / 2) - (dividerWidth / 2), y, dividerWidth, height);		
	}
	
	/**
	 * Draws a door with post box.
	 * @param g The graphics context to draw to.
	 * @param x The x coordinate of the door, i.e., the x value of the top left corner.
	 * @param y The y coordinate of the door, i.e., the y value of the top left corner. 
	 * @param width The width of the door.
	 * @param height The height of the door.
	 */
	public static void drawDoor(Graphics g, int x, int y, int width, int height) {
		// Draw background
		g.setColor(Color.RED);
		g.fillRect(x, y, width, height);
		 
		// Draw Post box
		g.setColor(Color.BLACK);		
		int postBoxY = y + (int) (0.50 * height); // 50% up from bottom of door
		int postBoxHeight = (int) (0.10 * height); // 10% of the height of door		
		int postBoxWidth = (int) (0.70 * width); // 70% of the width of door
		int postBoxX = x + (width / 2) - (postBoxWidth / 2);		
		g.fillRect(postBoxX, postBoxY, postBoxWidth, postBoxHeight);		
	}

}
